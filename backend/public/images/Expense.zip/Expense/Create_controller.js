const personModel = require('./Create_model')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken');


async function addperson(req, res) {
    try {
        const{firstName,lastName,email,password,confirmPassword}=req.body
        const salt = bcrypt.genSaltSync(12)

        const encpassword = bcrypt.hashSync(password, salt)
        const encconfirmPassword = bcrypt.hashSync( confirmPassword, salt)

          // Generate JWT token
          const token = jwt.sign({ email }, 'your-secret-key', { expiresIn: '1h' });
        
        const data = new personModel({
            firstName,
            lastName,
            email,
            password:encpassword,
            confirmPassword:encconfirmPassword,
            token: token  // Store the token in the database
            

        })
        const createData = await data.save()
        res.status(201).send({ msg: "person added successfully", createData })
    } catch (err) {
        res.status(400).send({ err })
    }
}

const findPerson = async (req, res) => {
    try {
        const personData = await personModel.find()
        res.status(200).send({ personData })
    } catch (err) {
        res.status(500).send(err)
    }
}
async function login(req, res) {
    try {

        const { email, password } = req.body

        const data = await personModel.findOne({ email })

        const compare = await bcrypt.compare(password, data.password)

        if (compare === true) {
            // Generate JWT token
            const token = jwt.sign({ email: data.email }, 'your-secret-key', { expiresIn: '1h' });

            res.status(200).send({ token, data });
        } else {
            res.status(400).send({ msg: "Email or password incorrect" });
        }
    } catch (error) {
        res.status(500).send(error);
    }
}

const verifyToken = (req, res, next) => {
    const token = req.header('Authorization');

    if (!token) {
        return res.status(401).send({ msg: 'Access denied. No token provided.' });
    }

    jwt.verify(token, 'your-secret-key', (err, decoded) => {
        if (err) {
            return res.status(403).send({ msg: 'Invalid token.' });
        }

        req.user = decoded;
        next();
    });
};



async function updateUser(req,res){
    try{
     // Verify token before updating user
        verifyToken(req, res);

        const{email}=req.params
        const{firstName,lastName}=req.body

        const data=await personModel.updateOne(
            {email},{$set:{firstName,lastName}}
        )
        if(data.modifiedCount>0){
            res.status(200).send({msg:"User updated successfully"})
        }else{
            res.status(400).send({msg:"You haven't updated any data"})
        }
    } catch(error){
        res.status(500).send(err)
    }
}




module.exports = {addperson,findPerson,login,updateUser}



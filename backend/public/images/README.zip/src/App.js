import { Routes ,Route } from 'react-router-dom';
import Hero from './Components/Hero';
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from './Components/Login'
function App() {



  return (
    <>
    
    <Routes>
      <Route path='/' element={<Hero/>}></Route>
      <Route path ="/login" element = {<Login/>}></Route>
    </Routes>
    </>
  );
}

export default App;

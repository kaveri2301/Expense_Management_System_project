import React from "react";
import '../Assests/Hero.css';
import imagewhite from './imageswhite.png'
import imagehero from '../Components/image2-removebg-preview.png'
import { Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";



export default function Hero() {
    const navigate =useNavigate();

function handleClick(){
    navigate("/login")
}
    return (
        <>
           
            <div className="main-bg d-flex align-items-center">
                <img className="imagewhite" src={imagewhite} alt="" />
                <img className="imagehero " src={imagehero} alt="" />
                <div className="text  mx-auto ">
                    <h1>Sumago<br /><span> Expense Management System</span> </h1>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae nemo odit quod assumenda laborum in ad iste molestiae asperiores sapiente ipsa aliquid eligendi, nobis magnam laboriosam commodi necessitatibus deleniti voluptatibus?
                    </p>
                    <div className="buttons " >
                        <Button className="p-2" style={{ backgroundColor: "#009688" }} onClick={handleClick}>Admin</Button>{' '}
                        <Button className="p-2" style={{ backgroundColor: "#009688" }}>User</Button>{' '}
                        <Button className="p-2" style={{ backgroundColor: "#009688" }}>Location Head</Button>{' '}
                    </div>

                </div>

            </div>
        </>
    )
}